package com.cg.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cg.demo.EmployeeDAO;
import com.cg.demo.EmployeeService;

@Configuration//This is a replacement of spring.xml
public class AppConfig {
	@Bean//Define a bean
	//syntax : public <ClassName> <Bean ID>(){.....}
	public EmployeeDAO dao(){
		return new EmployeeDAO();
	}
	@Bean
	public EmployeeService service(){
		EmployeeService service=new EmployeeService();
		service.setDao(dao());//Setter Injection with Java Syntax
		return service;
	}
}
