package com.cg.demo;

public class EmployeeDAO {

}
