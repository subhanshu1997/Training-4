package com.cg.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entities.Product;

@Controller
@RequestMapping("/add-product")
public class ProductController {
	@GetMapping
	public String showForm(Model model) {
		Product p = new Product();
		p.setPrice(100D);
		model.addAttribute("product", p);
		return "form";
	}

	@PostMapping
	public String submit(Model model,
			@ModelAttribute("product") Product product, BindingResult result) {
		String msg1 = "";
		if (!result.hasErrors()) {
			msg1 = "No Error";
			model.addAttribute("productName",product.getName());
			return "success";
		} else {
			msg1 = result.getErrorCount() + "Error Occurred";
		model.addAttribute("msg" + msg1);
		model.addAttribute("errors", result.getAllErrors());
		return "form";}
	}
}
