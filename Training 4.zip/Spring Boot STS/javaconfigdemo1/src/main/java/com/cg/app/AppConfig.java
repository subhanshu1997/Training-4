package com.cg.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cg.demo.EmployeeDAO;
import com.cg.demo.EmployeeService;

@Configuration//This is a replacement of spring.xml
@ComponentScan("com.cg.app")
public class AppConfig {
	
}
